from flask import Flask , render_template,request,redirect,session,url_for,flash

class Musica:
    def __init__(self,nome,cantorBandaGrupo,genero):
        self.nome=nome
        self.cantorBanda=cantorBandaGrupo
        self.genero=genero
        
musica01=Musica('Flor de Lis','Djavan','MPB')
musica02=Musica('Reiventar','Belo','Pagode/Samba')
musica03=Musica('Vuco bom','Livinho','Funk')

lista=[musica01,musica02,musica03]


class User:
    def __init__(self,nome,login,senha):
        self.nome=nome
        self.login=login
        self.senha=senha
        
u1=User("Raphael Lima","llimaraphael12","1234")
u2=User("Daniel de Paula","fadabey","1234")
u3=User("Lucas Neves","lunemamapeito","1234")

usuarios={u1.login:u1,
          u2.login:u2,
          u3.login:u3}

app =Flask(__name__)
app.secret_key= 'av3'


#CRIANDO UMA ROTA PARA IR DIRETO A HOME PAGE
@app.route('/')
def listaMusicas():
    
    if session['usuario_logado']== None or 'usuario_logado' not in session:
        return redirect(url_for('login'))

    return render_template('lista_musica.html', titulo ='eu to exausto',
                           musicas=lista)


#CADASTRO
@app.route('/cadastro')
def cadastroMusica():
    
    if session['usuario_logado']== None or 'usuario_logado' not in session:
        return redirect(url_for('login'))
    
    return render_template('cadastra.html')


#ADICIONANDO NOVO OBJETO DIRETO DO FORMS
@app.route('/adicionar',methods=['POST',])
def adicionar_musica():
    nome=request.form['txtNome']
    cantorBanda=request.form['txtCantor']
    genero=request.form['txtGenero']
    
    novaMusica=Musica(nome,cantorBanda,genero)
    
    lista.append(novaMusica)

    return redirect(url_for('listaMusica'))


#LOGIN
@app.route('/login')
def login():
    return render_template('login.html')


#AUTENTICAÇÃO
@app.route('/autenticar',methods=['POST',])
def autenticar():
    if request.form['txtLogin']in usuarios:
        
        usuarioEncontrado=usuarios[request.form['txtLogin']]
        
        if request.form['txtSenha']== usuarioEncontrado.senha:
        
            session['usuario_logado']= request.form['txtLogin']
        
            return redirect(url_for('listaMusicas'))
        else:
            return redirect(url_for('login'))
    else:
        flash("errou")
        return redirect(url_for('login'))
    
#finalizando a sessao do user
@app.route('/sair')
def sair():
    session['usuario_logado']= None    
    return redirect('/')
    
app.run(debug=True)
